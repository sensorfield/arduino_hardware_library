/*
  Copyright (c) 2014-2015 Arduino LLC.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "variant.h"

const PinDescription g_APinDescription[] = {
  // pin 0: SDA_INT (SERCOM3/PAD[0])
  { PORTA, 22, PIO_SERCOM,     (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 1: SCL_INT  (SERCOM3/PAD[1])
  { PORTA, 23, PIO_SERCOM,     (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 2: MODEM_TX  (SERCOM0/PAD[2])
  { PORTA, 10, PIO_SERCOM,     (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 3: MODEM_RX  (SERCOM0/PAD[3])
  { PORTA, 11, PIO_SERCOM,     (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 4: MOSI  (SERCOM1/PAD[0])
  { PORTA, 16, PIO_SERCOM,     (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 5: SCLK  (SERCOM1/PAD[1])
  { PORTA, 17, PIO_SERCOM,     (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 6: MISO  (SERCOM1/PAD[3])
  { PORTA, 19, PIO_SERCOM,     (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 7: SDA_EXT  (SERCOM2/PAD[0])
  { PORTA,  8, PIO_SERCOM_ALT, (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 8: SCL_EXT  (SERCOM2/PAD[1])
  { PORTA,  9, PIO_SERCOM_ALT, (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 9: BATT_MON
  { PORTA,  2, PIO_ANALOG,     (PIN_ATTR_DIGITAL|PIN_ATTR_ANALOG   ), ADC_Channel0,   NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 10: MODEM_ENABLE
  { PORTA,  4, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 11: SENSOR_PWR
  { PORTA,  5, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 12: MODEM_RST
  { PORTA,  6, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 13: LORA_SELECT
  { PORTA,  7, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 14: USB-
  { PORTA, 24, PIO_COM,        (PIN_ATTR_NONE                      ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 15: USB+
  { PORTA, 25, PIO_COM,        (PIN_ATTR_NONE                      ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 16: POWER_BUTTON
  { PORTA, 18, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_0    },
  // pin 17: LORA_SHUTDOWN
  { PORTA,  3, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 18: MODEM_TURNON
  { PORTA, 14, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 19: POWER_HOLD
  { PORTA, 15, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 20: LED_GREEN
  { PORTA, 27, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 21: LED_RED
  { PORTA, 28, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 22: SWCLK / AUX_SERIAL_TX (SERCOM1/PAD[2])
  { PORTA, 30, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 23: SWDIO / AUX_SERIAL_RX (SERCOM1/PAD[3])
  { PORTA, 31, PIO_DIGITAL,    (PIN_ATTR_DIGITAL                   ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 24: XTAL_IN
  { PORTA,  0, PIO_DIGITAL,    (PIN_ATTR_NONE                      ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // pin 25: XTAL_OUT
  { PORTA,  1, PIO_DIGITAL,    (PIN_ATTR_NONE                      ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
};

extern "C" {
    unsigned int PINCOUNT_fn() {
        return (sizeof(g_APinDescription) / sizeof(g_APinDescription[0]));
    }
}

const void* g_apTCInstances[TCC_INST_NUM + TC_INST_NUM]={ TCC0, TCC1, TCC2, TC3, TC4, TC5 };

// Multi-serial objects instantiation
SERCOM sercom0(SERCOM0);
SERCOM sercom1(SERCOM1);
SERCOM sercom2(SERCOM2);
SERCOM sercom3(SERCOM3);

// Serial1
#if 0
Uart Serial1(&sercom5, PIN_SERIAL1_RX, PIN_SERIAL1_TX, PAD_SERIAL1_RX, PAD_SERIAL1_TX);

void SERCOM5_Handler()
{
  Serial1.IrqHandler();
}
#endif

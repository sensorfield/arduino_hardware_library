# Parse intel hex file, check and/or insert image crc32
# according to input parameters.
import struct
import sys
import re

version = "3.1.0"

#
#  :020000040001F9
#   02  is length in bytes
#   0000  ?
#   04  is extended address record type
#   0001  is 31:16 of address
#   F9  is checksum
#
#
#  :100000002534DCA5282D6B2C66B608DCC694BB1302
#  10  is length of record in bytes
#  0000 is offset from base address in bytes
#  00  is data record type
#  2534DCA5282D6B2C66B608DCC694BB13 is data
#  02 is checksum
#
#
#  :10001000E940C5AC7F48455CBA57238A0CD23C24E2
#  :10002000005C42A3441250BBBFE2A5E9CDCA785F91
#  :1000300073606D7DAB7A945793436F79ACA8FA6C7B
#  :10004000EA61291EBC7ED7C8DDCA9B5C0FD37B2C1E
#  :100050008502FDBE32897E8FB08C58B5FD53C51820
#  :10006000C1E2FA435DD46E776CC4CF07052991A431
#  :1000700058F197A7FEC4ECF69B33FF9915B6679E1F
#  :100080001CD794542B4D7B88D17D9FD3621A7E8DD3
#  :10009000DE50D7862F50C0159190FD9B448F9E1047
#  :1000A000488E4FAB65FC5E4E27FBE0BF13CFFD4192
#  :1000B000C19AD0C11E2DD60F8C5564480F702313E2
#  :1000C0004AAFF9BB7ECB6BB94399DFE43A48C5B47C
#  :1000D00063A20ED85C2FFF9C3B8ABE4337C7A8E9BA
#  :1000E000E23ADB0E247CF24EB00F6374315E807313
#  :1000F000DE949462B305060F07920B49B3D8D36917
#  :100100008584B4493BAA3A2AB268A8B68CC0D4A068
#  :1001100004F3DE0C2336AE520F26C530B0BE4702C4
#  :10012000613EBB24E2C58004450A640C15F75DF707
#  :100130005F9ADE9DE51FB0E62A56DEE4966E9BBD13
#  :100140005C6FA0736B1AFB281EB2C4EFD063B0CCF7
#  :1001500031BC01F569F8C0E4EA8BBF6904B45F38CB
#  :1001600013758A2166C9DA7DA7756EEEF83C580BC7
#  :1001700073E42A095ACD87FF968849DCD2351CAC36
#  :10018000DD08183095CE438005C17FB3FE93DB3880
#  :10019000D8F6B4E99885A87F2E64D6730D6B54E821
#  :1001A000C83763BBF7F95447145B8DFE8F4FB56EAC
#  :1001B000CA2D73BC3BDFBF4869923879FDAD7C54D2
#  :1001C000996AF9F4C0F6237F685FA4A98E3159605B
#  :1001D0006B1BB2BF95705CD2B9DBB754202508F019
#  :1001E000CF5FE2275E47C06F4D444CA314D1355B0F
#  :1001F00094AD344A2FA70A2F445F167F2ED85E5342
#  :01020000A05D
#  :00000001FF
#
#  is end of file marker
#
#

class hexfile(object):
    '''Read in the hex file, validate and store all records'''
    def __init__(self):
        self.inhexfile = False
        self.outhexfile = False
        self.outbinfile = False
        self.lines = 1
        self.rec_types = { 'DATA':0, 'ENDOFDATA':1, 'SEGADDR':2, 'IPADDR':3, 'EXTADDR':4 }
        self.block_addr_list = []
        self.blocks = {}
        self.ext_addr = 0
        self.seg_addr = 0
        self.ip_addr = 0xffffffff
        self.total_length = 0
        self.adler32 = ""
        self.crc32 = ""
        self.checksum_sub = re.compile(r'%checksum%')
        self.adler32_ins = re.compile(r'%a')
        self.crc32_ins = re.compile(r'%c')

    def read_validate_store(self, filename):
        try:
            self.inhexfile = open(filename, 'r')
        except IOError:
            print('Error: input hex file {filename} not found'.format(filename))
            syntax(sys.argv[0])
            sys.exit(-1)
        else:
            if self.inhexfile:
                last_addr = -1
                self.ext_addr = 0
                self.reg_addr = 0
                # read in text file, parse fields:
                for line in self.inhexfile:
                    line = line.rstrip()
                    if len(line) < 11 or line[0] != ':':
                        print('Error line {} : invalid format'.format(str(self.lines)))
                        break
                    length = int(line[1:3],16)
                    offset = int(line[3:7],16)
                    rec_type = int(line[7:9],16)
                    data = []
                    checksum = int(length + (offset / 256) + (offset % 256) + rec_type)
                    for i in range(9,9+2*length,2):
                        val = int(line[i:i+2],16)
                        checksum = (checksum + val) & 0xff
                        data.append(val)
                    checksum = (256 - checksum) & 0xff
                    if checksum != int(line[-2:],16):
                        print('Error line {}: invalid checksum, ({})'.format(str(self.lines), checksum))
                        break
                    if rec_type == self.rec_types.get('SEGADDR') and length == 2:
                        self.seg_addr = int(line[9:13],16)
                    elif rec_type == self.rec_types.get('IPADDR') and length == 4:
                        self.ip_addr = int(line[9:17],16)
                    elif rec_type == self.rec_types.get('EXTADDR') and length == 2:
                        self.ext_addr = int(line[9:13],16)
                    elif rec_type == self.rec_types.get('ENDOFDATA') and length == 0:
                        break
                    elif rec_type == self.rec_types.get('DATA'):
                        addr = (self.ext_addr * 65536) + (self.seg_addr * 16) + offset
                        if addr != last_addr and data.__len__():
                            block_addr = addr
                            self.block_addr_list.append(block_addr)
                            self.blocks[block_addr] = data
                        else:
                            self.blocks[block_addr].extend(data)
                        last_addr = addr + length
                    else:
                        print('Error line {}: invalid record type, ({})'.format(str(self.lines), rec_type))
                        break
                    self.lines += 1

                # close and exit
                self.inhexfile.close()
                self.inhexfile = False

    def reconcile_overlaps(self):
        dup_list = []
        for i in range(len(self.block_addr_list) - 1):
            for block_addr1 in self.block_addr_list[:i]:
                block_addr2 = self.block_addr_list[i + 1]
                length1 = self.blocks[block_addr1].__len__()
                length2 = self.blocks[block_addr2].__len__()
                if block_addr2 >= block_addr1 and block_addr2 + length2 < block_addr1 + length1:
                    offset = block_addr2 - block_addr1
                    for j in range(length2):
                        self.blocks[block_addr1][offset + j] = self.blocks[block_addr2][j]
                    dup_list.append(block_addr2)
        for block_addr in dup_list:
            length = self.blocks[block_addr].__len__()
            print("dup:     0x%08x length: %d (0x%0x)"%(block_addr, length, length))
            self.block_addr_list.remove(block_addr)
            del self.blocks[block_addr]

    def sort_blocks(self):
        self.block_addr_list.sort()

    def find_and_fill_gaps(self, fill, start_addr, end_addr):
        gaps_addr_list = []
        last_addr = 0
        block = 0
        # print(start_addr, end_addr)
        for block_addr in self.block_addr_list:
            if last_addr:
                length = block_addr - last_addr
            else:
                length = 0
            # print("block_addr: 0x%0x  block_len: 0x%0x  last_addr: 0x%0x,  length: 0x%0x"%(block_addr, self.blocks[block_addr].__len__(), last_addr, length))
            if length > 0 and last_addr + length >= start_addr and last_addr < end_addr:
                if last_addr < start_addr:
                    last_addr = start_addr
                    length = block_addr - start_addr
                if last_addr + length >= end_addr:
                    length = end_addr - last_addr
                print("gap:     0x%08x length: %d (0x%0x)"%(last_addr, length, length))
                gaps_addr_list.append(last_addr)
                self.blocks[last_addr] = []
                for i in range(length):
                    self.blocks[last_addr].append(fill)
                self.total_length += length
            length = self.blocks[block_addr].__len__()
            print("block %d: 0x%08x length: %d (0x%0x)"%(block, block_addr, length, length))
            block += 1
            last_addr = block_addr + length
            self.total_length += length
        if gaps_addr_list.__len__():
            for block_addr in gaps_addr_list:
                self.block_addr_list.append(block_addr)
            self.sort_blocks()
        # print(self.block_addr_list)
        # print(self.blocks.keys())

    def print_blocks(self):
        print("lines =", self.lines)
        for block_addr in self.block_addr_list:
            print("0x%08x %d"%(block_addr, self.blocks[block_addr].__len__()))

    def print_data(self):
        print("block_addr_list:")
        print(self.block_addr_list)
        # print("blocks:")
        # print(self.blocks)

    def join_blocks(self, start_addr, end_addr):
        # print(self.block_addr_list)
        join_list = []
        begin_addr = end_addr
        for block_addr in self.block_addr_list:
            if block_addr >= start_addr and block_addr < end_addr:
                begin_addr = block_addr
                break
        for block_addr in self.block_addr_list:
            if block_addr > begin_addr and block_addr < end_addr:
                join_list.append(block_addr)
        for block_addr in join_list:
            self.blocks[begin_addr].extend(self.blocks[block_addr])
            self.block_addr_list.remove(block_addr)
            del self.blocks[block_addr]

    def write_ihex_file(self, filename, addr_delta):
        self.ext_addr = 0
        try:
            self.outhexfile = open(filename, 'wt')
            if self.outhexfile:
                if self.ext_addr:
                    self.write_ihex_record('EXTADDR', self.ext_addr, 0, 0)
                for block_addr in self.block_addr_list:
                    # print("writing block", block_addr)
                    offset = 0
                    length = self.blocks[block_addr].__len__()
                    while offset < length:
                        offset = self.write_ihex_record('DATA', block_addr, offset, addr_delta)

                if self.ip_addr != 0xffffffff:
                    self.write_ihex_record('IPADDR', 0, 0, 0)

                self.write_ihex_record('ENDOFDATA', 0, 0, 0)

        finally:
            # close and exit
            self.outhexfile.close()
            self.outhexfile = False

    def write_ihex_record(self, rec_type, block_addr, offset, addr_delta):
        data = []
        if rec_type == 'EXTADDR':
            self.ext_addr = block_addr
            length = 2
            rec_addr = 0
            block_addr = int(block_addr / 0x10000)
            data.extend([int(block_addr / 0x100), block_addr])
        elif rec_type == 'ENDOFDATA':
            length = 0
            rec_addr = 0
        elif rec_type == 'IPADDR':
            length = 4
            rec_addr = 0
            addr = self.ip_addr
            for i in range(4):
                data.append(addr & 0xff)
                addr = int(addr / 256)
            data.reverse()
        elif rec_type == 'DATA':
            length = self.blocks[block_addr].__len__() - offset
            if length > 16:
                length = 16
            rec_addr = (block_addr + offset + addr_delta) - self.ext_addr
            if rec_addr + length > 0xffff:
                if rec_addr > 0xffff:
                    self.write_ihex_record('EXTADDR', \
                            (block_addr + offset + addr_delta + length) & 0xffff0000, 0, 0)
                    rec_addr = (block_addr + offset + addr_delta) - self.ext_addr
                else:
                    length = 0x10000 - rec_addr
            data.extend(self.blocks[block_addr][offset:offset+length])

        checksum = int(rec_addr / 0x100) + (rec_addr % 0x100) + self.rec_types[rec_type]
        checksum = checksum + length
        if self.outhexfile:
            record = ":%02x%04x%02x"%(length, rec_addr, self.rec_types[rec_type])
            for i in range(length):
                record = record + "%02x"%data[i]
                checksum = checksum + data[i]
            checksum = (0x100 - checksum) & 0xff
            record = record + "%02x\n"%checksum
            self.outhexfile.write(record)
        return offset + length

    def write_bin_file(self, filename):
        try:
            self.outbinfile = open(filename, 'wb')
            if self.outbinfile:
                for block_addr in self.block_addr_list:
                    offset = 0
                    while offset < self.blocks[block_addr].__len__():
                        data = struct.pack('<4B', *self.blocks[block_addr][offset:offset+4])
                        self.outbinfile.write(data)
                        offset += 4

        finally:
            # close and exit
            self.outbinfile.close()
            self.outbinfile = False

    def compute_crc32(self, start_addr, end_addr):
        crc32 = 0xffffffff
        for block_addr in self.block_addr_list:
            # addr = block_addr
            length = self.blocks[block_addr].__len__()
            offset = 0
            while block_addr + offset >= start_addr and block_addr + offset < end_addr and offset < length:
                xr = self.blocks[block_addr][offset] << 24
                offset += 1
                crc32 = crc32 ^ xr
                for i in range(8):
                    if crc32 & 0x80000000:
                        crc32 = crc32 << 1
                        crc32 = crc32 ^ 0x04c11db7
                    else:
                        crc32 = crc32 << 1
            crc32 = crc32 & 0xffffffff
            self.crc32 = crc32 & 0xffffffff
        return self.crc32

    def append_crc32(self, start_addr, end_addr):
        # compute the crc32 across the given range and then print it
        crc32 = self.compute_crc32(parm.start_addr, parm.end_addr)
        print('crc32 = {}'.format(hex(crc32)))
        self.append_checkword(crc32, parm.end_addr)

    def compute_adler32(self, start_addr, end_addr):
        a = 1
        b = 0
        for block_addr in self.block_addr_list:
            # addr = block_addr
            length = self.blocks[block_addr].__len__()
            offset = 0
            while block_addr + offset >= start_addr and block_addr + offset < end_addr and offset < length:
                a = (a + self.blocks[block_addr][offset]) % 65521 # 65521 is ADLER modulus
                b = (b + a) % 65521
                offset += 1
        self.adler32 = (b << 16) | a
        return self.adler32

    def append_adler32(self, start_addr, end_addr):
        # compute the adler32 across the given range and then print it
        adler32 = self.compute_adler32(parm.start_addr, parm.end_addr)
        print('adler32 = {}'.format(hex(adler32)))
        self.append_checkword(adler32, parm.end_addr)

    def insert_length(self, length_addr, total_length):
        for i in range(4):
            for block_addr in self.block_addr_list:
                if length_addr >= block_addr \
                        and (length_addr - block_addr) < self.blocks[block_addr].__len__():
                    self.blocks[block_addr][(length_addr - block_addr)] = (total_length & 0xff)
                    total_length = int(total_length / 256)
                    length_addr += 1

    def append_checkword(self, checkword, end_addr):
        last_addr = 0
        for block_addr in self.block_addr_list:
            if block_addr + self.blocks[block_addr].__len__() < end_addr:
                last_addr = block_addr + self.blocks[block_addr].__len__()

        if last_addr:
            self.block_addr_list.append(last_addr)
            self.blocks[last_addr] = []
            for i in range(4):
                self.blocks[last_addr].append(checkword & 0xff)
                checkword = int(checkword / 256)

    def translate_filename(self, filename):
        if self.adler32 != "":
            filename = self.adler32_ins.sub("{:08x}".format(self.adler32), filename)
        if self.crc32 != "":
            filename = self.crc32_ins.sub("{:08x}".format(self.crc32), filename)
            return filename

class parms(object):
    '''Read and provide program parameters'''
    def __init__(self, args):
        self.executable = None
        self.parmfilename = None
        self.parmfile = None
        self.comment = re.compile(r'#')
        self.hex_val = re.compile(r'(0x)([\da-f]+)', re.IGNORECASE)
        self.dec_val = re.compile(r'[\da-f]+')
        self.hex_ext = re.compile(r'.*\.hex$', re.IGNORECASE)
        self.bin_ext = re.compile(r'.*\.bin$', re.IGNORECASE)
        self.inhexfile = ""
        self.overlayhexfile = ""
        self.outhexfile = ""
        self.outbinfile = ""
        self.start_addr = -1
        self.end_addr = 0
        self.fill = -1
        self.length_addr = -1
        self.move_addr = -1
        self.insert_length = False
        self.append_crc32 = 0
        self.append_adler32 = 0
        self.join = False

        parm = None
        for arg in args:
            if self.executable == None:
                self.executable = arg
            elif parm: # arg flag is set
                if parm == "-c":
                    self.parmfilename = arg
                elif parm == "-i":
                    self.inhexfile = arg
                elif parm == "-x":
                    self.overlayhexfile = arg
                elif parm == "-o":
                    if self.hex_ext.match(arg):
                        self.outhexfile = arg
                    elif self.bin_ext.match(arg):
                        self.outbinfile = arg
                elif parm == "-s":
                    self.start_addr = self.get(arg)
                elif parm == "-e":
                    self.end_addr = self.get(arg)
                elif parm == "-f":
                    self.fill = self.get(arg)
                elif parm == "-l":
                    self.length_addr = self.get(arg)
                    self.insert_length = True
                elif parm == "-m":
                    self.move_addr = self.get(arg)
                else:
                    print('Input error: {}'.format(parm))
                    raise ValueError
                parm = None
            else: # no arg flag; get one
                if arg == "-a":
                    # if both append_crc32 and append_adler32, remember which one is first
                    self.append_crc32 = self.append_adler32 + 1
                elif arg == "-b":
                    self.append_adler32 = self.append_crc32 + 1
                elif arg == "-j":
                    self.join = True
                else:
                    parm = arg

        if self.parmfilename == None:
            self.parmfilename = "ihexcrc32.cfg"
        try:
            # read configuration file
            self.parmfile = open(self.parmfilename, 'r')
        except IOError:
            self.parmfilename = ""
        else:
            # read in text file, parse fields:
            for line in self.parmfile:
                if not self.comment.match(line):
                    name_val = line.split(None, 3)
                    if name_val[0] == "inhexfile:":
                        if self.inhexfile == "":
                            self.inhexfile = name_val[1]
                    elif name_val[0] == "overlayhexfile:":
                        if self.overlayhexfile == "":
                            self.overlayhexfile = name_val[1]
                    elif name_val[0] == "outhexfile:":
                        if self.outhexfile == "":
                            self.outhexfile = name_val[1]
                    elif name_val[0] == "outbinfile:":
                        if self.outbinfile == "":
                            self.outbinfile = name_val[1]
                    elif name_val[0] == "start_addr:":
                        if self.start_addr == -1:
                            self.start_addr = self.get(name_val[1])
                    elif name_val[0] == "end_addr:":
                        if self.end_addr == 0:
                            self.end_addr = self.get(name_val[1])
                    elif name_val[0] == "fill:":
                        if self.fill == -1:
                            self.fill = self.get(name_val[1])
                    elif name_val[0] == "length_addr:":
                        if self.length_addr == -1:
                            self.length_addr = self.get(name_val[1])
                    elif name_val[0] == "move_addr:":
                        if self.move_addr == -1:
                            self.move_addr = self.get(name_val[1])
                    elif name_val[0] == "insert_length":
                        self.insert_length = True
                    elif name_val[0] == "append_crc32":
                        self.append_crc32 = self.append_adler32 + 1
                    elif name_val[0] == "append_adler32":
                        self.append_adler32 = self.append_crc32 + 1
                    elif name_val[0] == "join":
                        self.join = True
                    else:
                        raise ValueError
                    #, "invalid input"

            # close and exit
            self.parmfile.close()
            self.parmfile = None

        if self.start_addr == -1:
            self.start_addr = 0
        if self.end_addr == 0:
            self.end_addr = 0xffffffff
        if self.fill == -1:
            self.fill = 0
        if self.length_addr == -1:
            self.length_addr = 0
        if self.move_addr == -1:
            self.move_addr = 0

    def get(self, parm):
        '''get a numerical parameter'''
        val = 0
        if self.hex_val.match(parm):
            val = int(self.hex_val.sub(r'\2', parm, 1), 16)
        elif self.dec_val.match(parm):
            val = int(parm, 10)
        else:
            raise ValueError
        #, "Invalid address parameter"
        return val

    def print_all(self):
        '''print all parameters'''
        print(' parametersfile: {}'.format(self.parmfilename))
        print('      inhexfile: {}'.format(self.inhexfile))
        print(' overlayhexfile: {}'.format(self.overlayhexfile))
        print('     outhexfile: {}'.format(self.outhexfile))
        print('     outbinfile: {}'.format(self.outbinfile))
        print('     start_addr: {}'.format(hex(self.start_addr)))
        print('       end_addr: {}'.format(hex(self.end_addr)))
        print('           fill: {}'.format(hex(self.fill)))
        print('    length_addr: {}'.format(hex(self.length_addr)))
        print('      move_addr: {}'.format(hex(self.move_addr)))
        print('  insert_length: {}'.format(self.insert_length))
        print('   append_crc32: {}'.format(self.append_crc32))
        print(' append_adler32: {}'.format(self.append_adler32))
        print('           join: {}'.format(self.join))


def syntax(this_program):
    '''print program help message'''
    strip_py = re.compile(r'\.py')
    print('{} version {}'.format(this_program, version))
    print('syntax: {} <parameter list>'.format(this_program))
    print('  parameter list: ')
    print('     -c <paramter file name>')
    print('     -i <input hex file name>')
    print('     -x <overlay hex file name>')
    print('     -o <output hex file name ({filename}.hex)> | <output binary file name ({filename}.bin)>')
    print('     -s <start address of crc32 range>')
    print('     -e <end address of crc32 range>')
    print('     -f <data fill value (default 0)>')
    print('     -l <address to insert length>')
    print('     -m <address to move image to>')
    print('     -a (append_crc32)')
    print('     -b (append_adler32)')
    print('     -j (join)')
    print('  default configuration file: '.format(strip_py.sub(r'', this_program, 1)+".cfg"))
    print('  configuration file format:')
    print('  ---------------------------------------------------------')
    print('     inhexfile: <input hex file path/name>')
    print('    outhexfile: <output hex file path/name>')
    print('    outbinfile: <output binary file path/name>')
    print('    start_addr: <start address of crc32 range>')
    print('      end_addr: <end address of crc32 range>')
    print('          fill: <data fill value (default 0)>')
    print('   length_addr: <address to insert length>')
    print('     move_addr: <address to move image to>')
    print(' insert_length')
    print('  append_crc32')
    print('  append_adler32')
    print('          join')
    print('  ---------------------------------------------------------')


### Main entry point ###
# get program parameters
if len(sys.argv) < 2:
    # use default configuration file if no arguments
    parmfile = "ihexcrc32.cfg"
else:
    if sys.argv[1] == "-z" or sys.argv[1] == "--no-output":
        sys.exit(0)
    if sys.argv[1] == "-h" or sys.argv[1] == "--help":
        syntax(sys.argv[0])
        sys.exit(0)

parm = parms(sys.argv)
parm.print_all()

# check for errors in configuration
if parm.inhexfile == "":
    print("Error: input hex file not configured (default ihexcrc32.cfg)")
    syntax(sys.argv[0])
    sys.exit(-1)

if parm.start_addr >= parm.end_addr:
    print("Error: start_addr >= end_addr")
    syntax(sys.argv[0])
    sys.exit(-1)

# read in and validate hex file, then sort the blocks and fill any gaps between blocks
hf = hexfile()
hf.read_validate_store(parm.inhexfile)
if parm.overlayhexfile != "":
    hf.read_validate_store(parm.overlayhexfile)
hf.reconcile_overlaps()
hf.sort_blocks()
hf.find_and_fill_gaps(parm.fill, parm.start_addr, parm.end_addr)
print('total_length: {} ({})'.format(hf.total_length, hex(hf.total_length)))
# hf.print_data()
if parm.insert_length:
    hf.insert_length(parm.length_addr, hf.total_length)

if parm.append_crc32 and parm.append_adler32:
    if parm.append_crc32 < parm.append_adler32:
        # insert the crc32 into the data first, then adler32
        hf.append_crc32(parm.start_addr, parm.end_addr)
        hf.append_adler32(parm.start_addr, parm.end_addr)
    else:
        # insert the adler32 into the data first, then crc32
        hf.append_adler32(parm.start_addr, parm.end_addr)
        hf.append_crc32(parm.start_addr, parm.end_addr)

else:
    if parm.append_crc32:
        # insert the crc32 into the data
        hf.append_crc32(parm.start_addr, parm.end_addr)

    if parm.append_adler32:
        # insert the adler32 into the data
        hf.append_adler32(parm.start_addr, parm.end_addr)

# join blocks if configured to do so
if parm.join:
    hf.join_blocks(parm.start_addr, parm.end_addr)

# write out the modified hex file
# hf.print_data()
if parm.outhexfile != "":
    filename = hf.translate_filename(parm.outhexfile)
    addr_delta = 0
    if parm.move_addr:
        addr_delta = parm.move_addr - hf.block_addr_list[0]
    hf.write_ihex_file(filename, addr_delta)

# write out the binary file
if parm.outbinfile != "":
    filename = hf.translate_filename(parm.outbinfile)
    hf.write_bin_file(filename)

sys.exit(0)


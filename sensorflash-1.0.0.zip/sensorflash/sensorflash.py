# Sensorfield target board flashing program for SAMD21-based target boards.

version = "1.0.0"

import wx
import os
import configparser
import string
import sys
import struct
import re
import subprocess
from subprocess import Popen, PIPE
import threading
from threading import Timer

class Config(object):
	'''Read and provide program configuration'''
	def __init__(self):
		configpath = os.path.join(os.environ.get('LOCALAPPDATA') or
				os.environ.get('XDG_CONFIG_HOME') or
				os.path.join(os.environ['HOME'], '.config'), 'sensorfield_flash')
		os.makedirs(configpath, exist_ok = True)	# make sure we are using Python 3

		self.configfile = configpath + "/config.ini"
		print(self.configfile)
		if not os.path.isfile(self.configfile):
			config = configparser.ConfigParser()
			config.add_section('Arduino')
			if 'LOCALAPPDATA' in os.environ:
				self.arduino_path = os.environ.get('LOCALAPPDATA') + "/Arduino15"
			else:
				self.arduino_path = os.environ.get('HOME') + "/.arduino15"
			if not os.path.isdir(self.arduino_path):
				self.arduino_path = ''
			config['Arduino']['path'] = self.arduino_path
			config.add_section('control')
			config['control']['device_id'] = '0'
			config['control']['flash_boot'] = 'yes'
			config['control']['flash_app'] = 'no'
			config['control']['app_file'] = ''
			with open(self.configfile, 'w') as f:
				config.write(f)
				f.close()

		config = configparser.ConfigParser()
		config.read(self.configfile)
		self.arduino_path = config['Arduino']['path']
		self.device_id = int(config['control']['device_id'])
		self.flash_boot = config.getboolean('control', 'flash_boot')
		self.app_file = config['control']['app_file']
		if not os.path.isfile(self.app_file):
			self.flash_app = False
		else:
			self.flash_app = config.getboolean('control', 'flash_app')

	def write(self):
		config = configparser.ConfigParser()
		config.read(self.configfile)
		if (	self.arduino_path != config['Arduino']['path'] or
				self.device_id != int(config['control']['device_id']) or
				self.flash_boot != config.getboolean('control', 'flash_boot') or
				self.flash_app != config.getboolean('control', 'flash_app') or
				self.app_file != config['control']['app_file']):
			config['Arduino']['path'] = self.arduino_path
			config['control']['device_id'] = str(self.device_id)
			config['control']['flash_boot'] = 'yes' if self.flash_boot else 'no'
			config['control']['flash_app'] = 'yes' if self.flash_app else 'no'
			config['control']['app_file'] = self.app_file
			with open (self.configfile, 'w+') as f:
				config.write(f)
				f.close()

class RedirectText(object):
	def __init__(self, aWxTextCtrl):
		self.out = aWxTextCtrl
	def write(self, string):
		self.out.AppendText(string)
		# Use the following to print from threads:
		# wx.CallAfter(self.out.WriteText, string)

class FileMenu(wx.Menu):
	def __init__(self, parent):
		super(FileMenu, self).__init__()

		self.parent = parent

		menuItem1Text = 'location of Arduino root directory: ' + self.parent.config.arduino_path
		menuItem1 = wx.MenuItem(self, wx.ID_ANY, menuItem1Text)
		self.Append(menuItem1)
		self.Bind(wx.EVT_MENU, self.onFileMenuItem1, menuItem1)
		menuItem2Text = 'Application file: ' + self.parent.config.app_file
		menuItem2 = wx.MenuItem(self, wx.ID_ANY, menuItem2Text)
		self.Append(menuItem2)
		self.Bind(wx.EVT_MENU, self.onFileMenuItem2, menuItem2)

	def onFileMenuItem1(self, event):
		dialog = wx.DirDialog(None, 'location of Arduino root directory:',
				style=wx.DD_DEFAULT_STYLE | wx.DD_NEW_DIR_BUTTON)

		if dialog.ShowModal() == wx.ID_OK:
			path = dialog.GetPath()
			if not os.path.isdir(path):
				path = ''
			self.parent.config.arduino_path = path
			print(self.parent.config.arduino_path)

	def onFileMenuItem2(self, event):
		dialog = wx.FileDialog(None, 'Application file:',
				style=wx.DD_DEFAULT_STYLE | wx.DD_NEW_DIR_BUTTON)

		if dialog.ShowModal() == wx.ID_OK:
			path = dialog.GetPath()
			if not os.path.isfile(path):
				path = ''
				self.parent.flash_app = False
				self.parent.appCheckbox.SetValue(False)
			self.parent.config.app_file = path
			print(self.parent.config.app_file)

class Window(wx.Frame):
	def __init__(self, title, version):
		super().__init__(parent = None, title = title + '    version ' + version)
		self.rec_types = { 'DATA':0, 'ENDOFDATA':1, 'SEGADDR':2, 'IPADDR':3, 'EXTADDR':4 }
		self.ext_addr = 0
		self.ihexcrc32 = ''
		self.arduino_hw_path = ''
		self.bootloader_file = ''
		self.openocd_path = ''
		self.openocd_bin = ''
		self.openocd_scripts_path = ''
		self.variant_openocd_scripts_path = ''
		if 'LOCALAPPDATA' in os.environ:
			tmppath = os.path.join(os.environ.get('LOCALAPPDATA', 'Temp'))
		else:
			tmppath = "/tmp"
		self.bootloader_image_file = os.path.join(tmppath, 'bootloader_image.hex')
		self.bootloader_image_file = self.bootloader_image_file.replace(os.sep, '/')
		self.device_id_image_file = os.path.join(tmppath, 'device_id.hex')
		self.device_id_image_file = self.device_id_image_file.replace(os.sep, '/')

		panel = wx.Panel(self)
		# panel.SetBackgroundColour('#4f5049')

		# set up configuration file
		self.config = Config()

		self.device_id = self.config.device_id
		self.arduino_path = self.config.arduino_path
		self.app_file = self.config.app_file
		self.flash_boot = self.config.flash_boot
		self.flash_app = self.config.flash_app

		self.SetIcon(wx.Icon('./icons/icon_wxWidgets.ico', wx.BITMAP_TYPE_ICO))
		# self.SetBackgroundColour("gray")

		toolbar = wx.ToolBar(self, -1, style = wx.TB_HORIZONTAL | wx.NO_BORDER)
		toolbar.AddTool(1, "Exit", wx.Image('./bitmaps/exit.png',
			wx.BITMAP_TYPE_PNG).ConvertToBitmap(),
			wx.NullBitmap, wx.ITEM_NORMAL, 'Exit', '', None)
		# toolbar.SetToolLongHelp(toolId = 1, helpString = 'Exit this utility')
		toolbar.AddTool(2, "File", wx.Image('./bitmaps/save.png',
			wx.BITMAP_TYPE_PNG).ConvertToBitmap(),
			wx.NullBitmap, wx.ITEM_NORMAL, 'File', '', None)
		# toolbar.SetToolLongHelp(toolId = 2, helpString = 'Select Arduino and application file path')
		toolbar.AddSeparator()
		toolbar.AddStretchableSpace()
		toolbar.AddTool(3, "Flash", wx.Image('./bitmaps/redo.png',
			wx.BITMAP_TYPE_PNG).ConvertToBitmap(),
			wx.NullBitmap, wx.ITEM_NORMAL, 'Flash', '', None)
		# toolbar.SetToolLongHelp(toolId = 3, helpString = 'Flash bootloader and/or application images')
		self.Bind(wx.EVT_MENU, self.onExit, id = 1)
		self.Bind(wx.EVT_TOOL, self.onFile, id = 2)
		self.Bind(wx.EVT_TOOL, self.onFlashIdButtonPressed, id = 3)
		toolbar.Realize()

		vbox = wx.BoxSizer(wx.VERTICAL)
		vbox.Add(toolbar, 0, border = 10)

		decimalLabel = wx.StaticText(self, -1, "decimal:", style = wx.ALIGN_RIGHT)
		self.decimalText = wx.TextCtrl(self, -1, value = str(self.device_id), size = (175, -1))
		self.decimalText.SetInsertionPoint(0)
		self.decimalText.Bind(wx.EVT_CHAR, self.onDecimalKeyPressed)

		incButton = wx.Button(self, wx.ID_ANY, 'add 1', (10, 10))
		incButton.Bind(wx.EVT_BUTTON, self.onIncButtonPressed)

		hexLabel = wx.StaticText(self, -1, "hex:", style = wx.ALIGN_RIGHT)
		self.hexText = wx.TextCtrl(self, -1, value = str(hex(self.device_id)), size = (175, -1))
		self.hexText.SetMaxLength(10)
		self.hexText.SetInsertionPoint(0)
		self.hexText.Bind(wx.EVT_CHAR, self.onHexKeyPressed)

		self.bootCheckbox = wx.CheckBox(self, -1, label = "flash bootloader")
		self.bootCheckbox.SetValue(self.config.flash_boot)
		self.bootCheckbox.Bind(wx.EVT_CHECKBOX, self.onBootChecked)
		self.appCheckbox = wx.CheckBox(self, -1, label = "flash application")
		self.appCheckbox.SetValue(self.config.flash_app)
		self.appCheckbox.Bind(wx.EVT_CHECKBOX, self.onAppChecked)

		self.log = wx.TextCtrl(self, wx.ID_ANY, size = (900, 500),
				style = wx.TE_MULTILINE|wx.TE_READONLY|wx.TE_BESTWRAP)

		sizer = wx.GridBagSizer(vgap = 10, hgap = 10)
		sizer.Add(decimalLabel, pos = (0, 0), flag = wx.ALL, border = 10)
		sizer.Add(self.decimalText, pos = (0, 1), flag = wx.ALL, border = 10)
		sizer.Add(incButton, pos = (0, 2), flag = wx.ALL, border = 10)
		sizer.Add(hexLabel, pos = (1, 0), flag = wx.ALL, border = 10)
		sizer.Add(self.hexText, pos = (1, 1), flag = wx.ALL, border = 10)
		sizer.Add(self.bootCheckbox, pos = (1, 2), flag = wx.ALL, border = 10)
		sizer.Add(self.appCheckbox, pos = (1, 3), flag = wx.ALL, border = 10)
		sizer.Add(self.log, pos = (2, 0), span = (0, 4), flag = wx.ALL, border = 10)

		vbox.Add(sizer, flag = wx.ALL|wx.EXPAND, border = 10)
		self.SetSizer(vbox)

		self.statusbar = self.CreateStatusBar()
		self.statusbar.SetMinHeight(30)
		# self.statusbar.SetBackgroundColour((200, 188, 73, 243))
		self.statusbar.SetFieldsCount(3)
		self.statusbar.SetStatusWidths([-3, -1, -1])
		self.statusbar_text = wx.StaticText(self.statusbar, -1, '', pos = (8, 4))

		# redirect text here
		redir = RedirectText(self.log)
		sys.stdout = redir
		sys.stderr = redir

		print("Arduino root: {}".format(self.config.arduino_path))
		print("application file: {}".format(self.config.app_file))

		self.SetSize(950, 800)
		self.Centre()
		self.Show()

		self.timer = Timer(0.1, self.yieldForOutput)

	def yieldForOutput(self):
		wx.GetApp().Yield()

	def setStatusBarText(self, text, color):
		# self.statusbar.SetStatusText('flashing application')
		self.statusbar_text.SetForegroundColour(wx.Colour(color))
		self.statusbar_text.SetLabel(text)


	def onDecimalKeyPressed(self, event):
		keycode = event.GetKeyCode()
		obj = event.GetEventObject()
		if keycode == wx.WXK_NONE:
			pass
		elif chr(keycode) not in string.printable:
			event.Skip()
		elif chr(keycode) in string.digits:
			# insert new string with allowed characters only.
			text = obj.GetValue()
			position = obj.GetInsertionPoint()
			text = text[:position] + chr(keycode) + text[position:]
			if int(text) <= 0xffffffff:
				event.Skip()
		elif chr(keycode) in string.whitespace:
			self.device_id = int(obj.GetValue())
			self.hexText.SetValue(str(hex(self.device_id)))
		else:
			pass

	def onHexKeyPressed(self, event):
		keycode = event.GetKeyCode()
		obj = event.GetEventObject()
		if keycode == wx.WXK_NONE:
			pass
		elif chr(keycode) not in string.printable:
			event.Skip()
		elif chr(keycode) in string.hexdigits:
			event.Skip()
		elif chr(keycode) in string.whitespace:
			self.device_id = int(obj.GetValue()[2:], 16)
			self.decimalText.SetValue(str(self.device_id))
		else:
			pass

	def onIncButtonPressed(self, event):
		self.device_id = int(self.decimalText.GetValue())
		if self.device_id + 1 <= 0xffffffff:
			self.device_id += 1
		self.decimalText.SetValue(str(self.device_id))
		self.hexText.SetValue(str(hex(self.device_id)))

	def onBootChecked(self, event):
		self.config.flash_boot = self.bootCheckbox.GetValue()

	def onAppChecked(self, event):
		value = self.appCheckbox.GetValue()
		if value and not os.path.isfile(self.config.app_file):
			value = False
			self.appCheckbox.SetValue(False)
			print("Error file {} does not exist".format(self.config.app_file))
		self.config.flash_app = value

	def onFlashIdButtonPressed(self, event):
		self.log.SetValue('')	# clear log
		self.device_id = int(self.decimalText.GetValue())
		self.hexText.SetValue(str(hex(self.device_id)))
		self.config.device_id = self.device_id
		print('device_id: %d (0x%08x)'%(self.device_id, self.device_id))
		self.resolveArduinoHwRevision()
		self.resolve_openocd()
		if self.config.flash_boot:
			self.writeDeviceIdHexFile()
			self.resolve_ihexcrc32()
			self.writeMergedBootloaderFile()
			self.resolveBootloaderFile()
			if self.config.flash_boot and self.bootloader_file:
				self.mergeDeviceIdIntoBootloaderImage()
				self.flashBootloader()
		if self.config.flash_app and os.path.isfile(self.config.app_file):
			self.flashApplication()

	def onExit(self, event):
		self.config.write()
		self.Close()

	def onFile(self, event):
		self.PopupMenu(FileMenu(self))

	def flashApplication(self):
		app_file = self.config.app_file.replace(os.sep, '/')
		openocd_command = ('telnet_port disabled; program ' + app_file + ' verify reset; shutdown')
		args = ['echo', self.openocd_bin, '-d2', '-s', self.openocd_scripts_path, '-f',
				self.variant_openocd_scripts_path, '-c', openocd_command]

		echo = Popen(args, stdout = PIPE, stderr = PIPE)
		print(echo.communicate()[0].decode('utf-8')) # stdout
		print(echo.communicate()[1].decode('utf-8')) # stderr
		print("flashing application ...")
		self.setStatusBarText('flashing application ...', wx.BLUE)
		del args[0]
		process = Popen(args, stdout = PIPE, stderr = PIPE)
		print(process.communicate()[0].decode('utf-8')) # stdout
		print(process.communicate()[1].decode('utf-8')) # stderr
		passing_result_string = re.compile(r'\*\* Verified OK \*\*')
		result = True if passing_result_string.search(self.log.GetValue()) != None else False
		if result:
			print('passed')
			self.setStatusBarText('flashing application passed', wx.GREEN)
		else:
			print('failed')
			self.setStatusBarText('flashing application failed', wx.RED)

	def flashBootloader(self):
		openocd_command = ('telnet_port disabled; init; halt; at91samd chip-erase;'
							'reset halt; at91samd bootloader 0; program '
							+ self.bootloader_image_file +
							' verify reset; shutdown')
		args = ['echo', self.openocd_bin, '-d2', '-s', self.openocd_scripts_path, '-f',
				self.variant_openocd_scripts_path, '-c', openocd_command]

		echo = Popen(args, stdout = PIPE, stderr = PIPE)
		print(echo.communicate()[0].decode('utf-8')) # stdout
		print(echo.communicate()[1].decode('utf-8')) # stderr
		del args[0]
		print("flashing bootloader ...")
		self.setStatusBarText('flashing bootloader ...', wx.BLUE)
		process = Popen(args, stdout = PIPE, stderr = PIPE)
		print(process.communicate()[0].decode('utf-8')) # stdout
		print(process.communicate()[1].decode('utf-8')) # stderr
		passing_result_string = re.compile(r'\*\* Verified OK \*\*')
		result = True if passing_result_string.search(self.log.GetValue()) != None else False
		if result:
			print('passed')
			self.setStatusBarText('flashing bootloader passed', wx.GREEN)
		else:
			print('failed')
			self.setStatusBarText('flashing bootloader failed', wx.RED)

	def mergeDeviceIdIntoBootloaderImage(self):
		process = Popen(['python', self.ihexcrc32, '-i', self.bootloader_file,
			'-x', self.device_id_image_file, '-o', self.bootloader_image_file],
			stdout = PIPE, stderr = PIPE)
		if process.communicate()[1]: # stderr
			print(process.communicate()[1].decode('utf-8'))

	def resolveBootloaderFile(self):
		bootloader_string = re.compile(r'bootloader-sensorfield-samd21-.*.hex')
		bootloader_path = os.path.join(self.arduino_hw_path, 'bootloaders')
		bootloader_path.replace(os.sep, '/')
		process = Popen(['ls', bootloader_path], stdout = PIPE, stderr = PIPE)
		if process.communicate()[1]: # stderr
			print(process.communicate()[1].decode('utf-8'))
		bootloader_files = process.communicate()[0].split() # stdout
		bootloader_file = None
		for bl_file in bootloader_files:
			if bootloader_string.match(bl_file.decode('utf-8')):
				bootloader_file = bl_file.decode('utf-8')
				break
		if bootloader_file:
			self.bootloader_file = os.path.join(bootloader_path, bootloader_file)
			self.bootloader_file.replace(os.sep, '/')

	def resolveArduinoHwRevision(self):
		arduino_hw_path = os.path.join(self.config.arduino_path, 'packages', 'Sensorfield', 'hardware', 'samd')
		process = Popen(['ls', arduino_hw_path], stdout = PIPE, stderr = PIPE)
		if process.communicate()[1]: # stderr
			print(process.communicate()[1].decode('utf-8'))
		revisions = process.communicate()[0].split() # stdout
		revision_strs = []
		for revision in revisions:
			revision_strs.append(revision.decode('utf-8'))
		revision_strs.sort()
		revision_strs.reverse()
		self.arduino_hw_path = os.path.join(arduino_hw_path, revision_strs[0])
		self.arduino_hw_path.replace(os.sep, '/')

	def resolve_openocd(self):
		openocd = os.path.join(self.config.arduino_path, 'packages', 'Sensorfield', 'tools', 'openocd')
		process = Popen(['ls', openocd], stdout = PIPE, stderr = PIPE)
		if process.communicate()[1]: # stderr
			print(process.communicate()[1].decode('utf-8'))
		revisions = process.communicate()[0].split() # stdout
		revision_strs = []
		for revision in revisions:
			revision_strs.append(revision.decode('utf-8'))
		revision_strs.sort()
		revision_strs.reverse()
		self.openocd_path = os.path.join(openocd, revision_strs[0])
		if os.name == 'nt': # Windows
			self.openocd_bin = os.path.join(self.openocd_path, 'bin', 'openocd.exe')
		else:
			self.openocd_bin = os.path.join(self.openocd_path, 'bin', 'openocd')
		self.openocd_bin.replace(os.sep, '/')
		self.openocd_scripts_path = os.path.join(self.openocd_path, 'scripts')
		self.variant_openocd_scripts_path = os.path.join(self.arduino_hw_path,
				'variants/sensorfield_samd21/openocd_scripts/sensorfield_samd21.cfg')
		self.variant_openocd_scripts_path.replace(os.sep, '/')

	def resolve_ihexcrc32(self):
		ihexcrc32 = os.path.join(self.config.arduino_path, 'packages', 'Sensorfield', 'tools', 'ihexcrc32')
		ihexcrc32.replace(os.sep, '/')
		process = Popen(['ls', ihexcrc32], stdout = PIPE, stderr = PIPE)
		if process.communicate()[1]: # stderr
			print(process.communicate()[1].decode('utf-8'))
		revisions = process.communicate()[0].split() # stdout
		revision_strs = []
		for revision in revisions:
			revision_strs.append(revision.decode('utf-8'))
		revision_strs.sort()
		revision_strs.reverse()
		self.ihexcrc32 = os.path.join(ihexcrc32, revision_strs[0], 'ihexcrc32.py')
		self.ihexcrc32.replace(os.sep, '/')

	def writeMergedBootloaderFile(self):
		print(self.arduino_hw_path)

	def writeDeviceIdHexFile(self):
		with open(self.device_id_image_file, 'wt') as f:
			self.blocks = {}
			data = []
			block_addr = 0xb4	# Device ID location
			device_id = self.device_id
			for i in range(4):
				data.append(int(device_id % 256))
				device_id /= 256
			self.blocks[block_addr] = data
			self.writeIhexRecord(f, 'DATA', block_addr, 0, 0)
			f.close()

	def writeIhexRecord(self, outfile, rec_type, block_addr, offset, addr_delta):
		data = []
		if rec_type == 'EXTADDR':
			self.ext_addr = block_addr
			length = 2
			rec_addr = 0
			block_addr = int(block_addr / 0x10000)
			data.extend([int(block_addr / 0x100), block_addr])
		elif rec_type == 'ENDOFDATA':
			length = 0
			rec_addr = 0
		elif rec_type == 'IPADDR':
			length = 4
			rec_addr = 0
			addr = self.ip_addr
			for i in range(4):
				data.append(addr & 0xff)
				addr = int(addr / 256)
			data.reverse()
		elif rec_type == 'DATA':
			length = self.blocks[block_addr].__len__() - offset
			if length > 16:
				length = 16
			rec_addr = (block_addr + offset + addr_delta) - self.ext_addr
			if rec_addr + length > 0xffff:
				if rec_addr > 0xffff:
					self.write_ihex_record('EXTADDR', \
							(block_addr + offset + addr_delta + length) & 0xffff0000, 0, 0)
					rec_addr = (block_addr + offset + addr_delta) - self.ext_addr
				else:
					length = 0x10000 - rec_addr
			data.extend(self.blocks[block_addr][offset:offset+length])

		checksum = int(rec_addr / 0x100) + (rec_addr % 0x100) + self.rec_types[rec_type]
		checksum = checksum + length
		if outfile:
			record = ":%02x%04x%02x"%(length, rec_addr, self.rec_types[rec_type])
			for i in range(length):
				record = record + "%02x"%data[i]
				checksum = checksum + data[i]
			checksum = (0x100 - checksum) & 0xff
			record = record + "%02x\n"%checksum
			outfile.write(record)
		return offset + length

### Main entry point ###
app = wx.App()
window = Window('Sensorfield sensorflash utility', version)
app.MainLoop()
